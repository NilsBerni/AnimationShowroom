//
//  SwiftUIView.swift
//
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

@main
struct AnimationShowroomApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
