//
//  AnimationHash.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct AnimationHash: Identifiable {
    var id = UUID()
    var animation: Animation
}
