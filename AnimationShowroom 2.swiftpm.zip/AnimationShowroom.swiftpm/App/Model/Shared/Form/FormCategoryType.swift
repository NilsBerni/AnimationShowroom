//
//  FormCategoryType.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

enum FormCategoryType: String {
    case blend, shape, transform
}
