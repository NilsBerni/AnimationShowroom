//
//  FormType.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

enum FormType: String {
    case opacity, color, shadow,
         cornerRadius, width, height,
         xFlip, yFlip, zFlip, rotate
    
    var code: AttributedString {
        AttributedString(text: text, highlight: highlight)
    }
    
    var text: String {
        switch (self) {
        case .opacity:
            return "content.opacity(\n    move ? 0 : 1.0\n)"
        case .color:
            return "content.overlay(\n    move ?\n    Color.accentColor :\n    Color.primary\n)"
        case .shadow:
            return "content.shadow(\n    color: .primary,\n    radius: move ? 100 : 0,\n    x: 0,\n    y: 0\n)"
        case .cornerRadius:
            return "content.cornerRadius(\n    move ? 80 : 0\n)"
        case .width:
            return "content.scaleEffect(\n    move ?\n    CGSize(width: 1, height: 1) :\n    CGSize(width: 0.2, height: 1)\n)"
        case .height:
            return "content.scaleEffect(\n    move ?\n    CGSize(width: 1, height: 1) :\n    CGSize(width: 1, height: 0.2)\n)"
        case .xFlip:
            return "content.rotation3DEffect(\n    .degrees(move ? 180 : 0),\n    axis: (\n       x: 1,\n       y: 0,\n       z: 0)\n)"
        case .yFlip:
            return "content.rotation3DEffect(\n    .degrees(move ? 180 : 0),\n    axis: (\n       x: 0,\n       y: 1,\n       z: 0)\n)"
        case .zFlip:
            return "content.rotation3DEffect(\n    .degrees(move ? 180 : 0),\n    axis: (\n       x: 0,\n       y: 0,\n       z: 1)\n)"
        case .rotate:
            return "content.rotationEffect(\n    .degrees(move ? 180 : 0)\n)"
        }
    }
    
    var highlight: [String] {
        switch (self) {
        case .opacity:
            return ["opacity"]
        case .color:
            return ["overlay"]
        case .shadow:
            return ["shadow", "color", "radius", " x", " y"]
        case .cornerRadius:
            return ["cornerRadius"]
        case .width:
            return ["scaleEffect"]
        case .height:
            return ["scaleEffect"]
        case .xFlip:
            return ["rotation3DEffect", "axis", "degrees", " x", " y", " z"]
        case .yFlip:
            return ["rotation3DEffect", "axis", "degrees", " x", " y", " z"]
        case .zFlip:
            return ["rotation3DEffect", "axis", "degrees", " x", " y", " z"]
        case .rotate:
            return ["rotationEffect", "degrees"]
        }
    }
}
