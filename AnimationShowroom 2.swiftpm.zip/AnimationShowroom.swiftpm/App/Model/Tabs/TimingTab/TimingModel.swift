//
//  TimingModel.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct TimingModel {
    var type: AnimationType
    
    var animation: Animation {
        switch (type) {
        case .linear:
            return .linear(duration: 1)
        case .easeIn:
            return .easeIn(duration: 1)
        case .easeOut:
            return .easeOut(duration: 1)
        case .easeInOut:
            return .easeInOut(duration: 1)
        case .spring:
            return .spring()
        }
    }
    
    var repetitiveAnimation: AnimationHash {
        return AnimationHash(animation: animation.repeatForever(autoreverses: true))
    }
    
    var startEase: Bool {
        switch (type) {
        case .linear:
            return false
        case .easeIn:
            return true
        case .easeOut:
            return false
        case .easeInOut:
            return true
        case .spring:
            return false
        }
    }
    
    var endEase: Bool {
        switch (type) {
        case .linear:
            return false
        case .easeIn:
            return false
        case .easeOut:
            return true
        case .easeInOut:
            return true
        case .spring:
            return true
        }
    }
    
    var spring: Bool {
        return type == .spring
    }
}
