//
//  AnimationType.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

enum AnimationType: String {
    case linear, easeIn, easeOut, easeInOut, spring
    
    var code: AttributedString {
        switch(self) {
        case .linear:
            return AttributedString(text: "Animation.linear(duration: 1)", highlight: "linear")
        case .easeIn:
            return AttributedString(text: "Animation.easeIn(duration: 1)", highlight: "easeIn")
        case .easeOut:
            return AttributedString(text: "Animation.easeOut(duration: 1)", highlight: "easeOut")
        case .easeInOut:
            return AttributedString(text: "Animation.easeInOut(duration: 1)", highlight: "easeInOut")
        case .spring:
            return AttributedString(text: "Animation.spring()", highlight: "spring")
        }
    }
}
