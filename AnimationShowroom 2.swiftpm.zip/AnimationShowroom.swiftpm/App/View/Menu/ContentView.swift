//
//  SwiftUIView.swift
//
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink(destination: TimingView()) {
                    AnimationRow(title: "Timing", description: "Learn about animation timing curves.", systemName: "timer")
                }
                NavigationLink(destination: SpringView()) {
                    AnimationRow(title: "Spring", description: "Customize your spring animation.", systemName: "slider.vertical.3")
                }
                NavigationLink(destination: MoveView()) {
                    AnimationRow(title: "Move", description: "Move the white dot vertically and horizontally.", systemName: "arrow.up.and.down.and.arrow.left.and.right")
                }
                NavigationLink(destination: BlendView()) {
                    AnimationRow(title: "Blend", description: "Discover different blend animations.", systemName: "camera.filters")
                }
                NavigationLink(destination: ShapeView()) {
                    AnimationRow(title: "Shape", description: "See how animate shape changes.", systemName: "square.fill.on.circle.fill")
                }
                NavigationLink(destination: TransformView()) {
                    AnimationRow(title: "Transform", description: "Explore more complex view transformations.", systemName: "perspective")
                }
            }
            .navigationTitle("Animations")

            TimingView()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
