//
//  SwiftUIView.swift
//
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct AnimationRow: View {
    let title: String
    let description: String
    let systemName: String
    
    var icon: some View {
        Image(systemName: systemName)
            .frame(width: 50)
            .font(Font.system(size: 40))
            .foregroundColor(.accentColor)
    }
    
    var text: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .padding(.bottom, 2)
            Text(description)
                .foregroundColor(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }.padding(10)
    }
    
    var body: some View {
        HStack {
            icon
            text
        }
    }
}

struct AnimationRow_Previews: PreviewProvider {
    static var previews: some View {
        AnimationRow(title: "Timing", description: "Learn about animation timing curves.", systemName: "arrow.up.and.down.and.arrow.left.and.right")
    }
}
