//
//  MoveConfigureView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct MoveConfigureView: View {
    @Binding var x: Bool
    @Binding var y: Bool
    
    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            VStack(alignment: .leading) {
                Text(AttributedString(text: "dot.offset(", highlight: "offset"))
                Text(AttributedString(text: "    x: move ? \(x ? "width" : "0") : 0,", highlight: "x"))
                Text(AttributedString(text: "    y: move ? \(y ? "height" : "0") : 0,", highlight: "y"))
                Text(")")
            }
            .font(Font.title2.bold())
            .lineLimit(1)
            Spacer()
            ToggleView(title: "move on X axis: ", isOn: $x)
            ToggleView(title: "move on Y axis: ", isOn: $y)
        }.padding(40)
            .tint(.accentColor)
    }
}
