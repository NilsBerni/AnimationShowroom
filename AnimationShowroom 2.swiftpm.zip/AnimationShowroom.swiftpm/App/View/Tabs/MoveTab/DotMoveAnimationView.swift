//
//  DotMoveAnimationView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct DotMoveAnimationView: View {
    @Binding var move: Bool
    @Binding var animate: Bool
    var x: Bool
    var y: Bool
    
    var circle: some View {
        Circle()
            .stroke(.primary)
            .frame(width: 40, height: 40)
            .padding()
    }
    
    var body: some View {
        VStack {
            GeometryReader { geometry in
                let rightXOffset = x ? geometry.size.width - 72 : 0.0
                let rightYOffset = y ? geometry.size.height - 88 : 0.0
                
                VStack(spacing: 40) {
                    ZStack {
                        HStack {
                            circle
                            Spacer()
                            circle
                        }
                        if self.animate {
                            VStack {
                                HStack {
                                    Circle()
                                        .fill(.primary)
                                        .frame(width: 30, height: 30)
                                        .offset(x: self.move ? rightXOffset : 0, y: self.move ? rightYOffset : 0)
                                        .animation(
                                            self.animate ? .easeInOut(duration: 1).repeatForever(autoreverses: true) : nil,
                                            value: self.move
                                        )
                                        .padding(5)
                                    Spacer()
                                }
                            }
                            .padding(.horizontal)
                            .frame(height: 40)
                            .transition(.scale)
                        }
                    }
                    .padding(.top, 20)
                    
                    HStack {
                        circle
                        Spacer()
                        circle
                    }
                }
            }
            .frame(height: 200)
        }
        .padding()
    }
}
