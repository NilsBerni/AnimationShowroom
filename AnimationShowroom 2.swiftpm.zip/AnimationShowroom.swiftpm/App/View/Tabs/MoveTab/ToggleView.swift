//
//  ToggleView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct ToggleView: View {
    var title: String
    @Binding var isOn: Bool
    
    var body: some View {
        HStack {
            Toggle(title, isOn: $isOn)
                .font(.title2)
        }
        .padding()
        .background(Color.systemBackground)
        .cornerRadius(10)
    }
}
