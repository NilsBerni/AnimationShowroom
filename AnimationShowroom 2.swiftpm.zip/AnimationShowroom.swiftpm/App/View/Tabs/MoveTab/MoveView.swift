//
//  MoveView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct MoveView: View {
    @StateObject var vm = MoveViewModel()
    @Environment(\.colorScheme) var colorScheme
    
    var selectAnimation: some View {
        ZStack {
            CardView()
            MoveConfigureView(x: $vm.x, y: $vm.y)
        }
        .padding(.bottom, 30)
    }
    
    var body: some View {
        VStack {
            DotMoveAnimationView(move: $vm.move, animate: $vm.animate, x: vm.x, y: vm.y)
            Spacer()
            selectAnimation
        }
        .navigationTitle("Move")
        .onChange(of: vm.x, perform: { _ in
            vm.resetAnimation()
        })
        .onChange(of: vm.y, perform: { _ in
            vm.resetAnimation()
        })
        .onAppear(perform: self.vm.initiateAnimation)
    }
}



struct MoveView_Previews: PreviewProvider {
    static var previews: some View {
        MoveView()
    }
}

