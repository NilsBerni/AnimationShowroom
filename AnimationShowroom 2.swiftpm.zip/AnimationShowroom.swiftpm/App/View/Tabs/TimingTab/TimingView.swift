//
//  SwiftUIView.swift
//
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI


struct TimingView: View {
    @StateObject var vm = TimingViewModel()
    @Environment(\.colorScheme) var colorScheme
    
    var selectAnimation: some View {
        TabView(selection: $vm.selectedItem) {
            ForEach(vm.animations.indices, id: \.self) { index in
                TimingAnimationTabView(selected: vm.animations[index])
                    .tag(index)
            }
        }
        .tabViewStyle(.page)
        .indexViewStyle(.page(backgroundDisplayMode: colorScheme == .dark ? .never : .always))
    }
    
    var body: some View {
        VStack {
            DotAnimationView(move: $vm.move, animate: $vm.animate, animation: vm.selectedAnimation.repetitiveAnimation)
            Spacer()
            selectAnimation
        }
        .navigationTitle("Timing")
        .onChange(of: vm.selectedItem, perform: { _ in
            vm.resetAnimation()
        })
        .onAppear(perform: self.vm.initiateAnimation)
    }
}



struct TimingView_Previews: PreviewProvider {
    static var previews: some View {
        TimingView()
    }
}
