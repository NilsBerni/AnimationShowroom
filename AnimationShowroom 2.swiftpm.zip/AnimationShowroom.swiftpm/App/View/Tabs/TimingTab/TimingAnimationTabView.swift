//
//  TimingAnimationTabView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct TimingAnimationTabView: View {
    var selected: TimingModel
    
    var body: some View {
        ZStack {
            CardView()
            VStack(spacing: 40) {
                Text("\(selected.type.code)")
                    .font(.title).bold()
                    .minimumScaleFactor(0.5)
                    .lineLimit(1)
                GeometryReader { geometry in
                    let w = geometry.size.width
                    let h = geometry.size.height
                    Path { path in
                        path.move(to: CGPoint(x: 0, y: h))
                        path.addCurve(to: CGPoint(x: w, y: selected.spring ? h / 5 : 0),
                                      control1: CGPoint(x: w * (selected.startEase ? 0.6 : 0.5), y: (selected.startEase ? h : h / 2)),
                                      control2: CGPoint(x: w * (selected.endEase ? 0.4 : 1), y: 0))
                    }
                    .stroke(.blue, lineWidth: 10)
                }
            }.padding(40)
        }
        .padding(.bottom, 30)
    }
}

struct TimingAnimationTabView_Previews: PreviewProvider {
    static var previews: some View {
        TimingAnimationTabView(selected: TimingModel(type: .linear))
    }
}
