//
//  CardView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct CardView: View {
    var body: some View {
        Rectangle()
            .fill(Color.secondarySystemBackground)
            .cornerRadius(20)
            .padding()
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView()
    }
}
