//
//  DotAnimationView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct DotAnimationView: View {
    @Binding var move: Bool
    @Binding var animate: Bool
    var animation: AnimationHash
    
    var dot: some View {
        GeometryReader { geometry in
            let rightXOffset = geometry.size.width - 40
            Circle()
                .fill(.primary)
                .frame(width: 30, height: 30)
                .offset(x: self.move ? rightXOffset : 0, y: 0.0)
                .animation(
                    self.animate ? animation.animation : nil,
                    value: self.move
                )
                .padding(5)
        }
        .padding(.horizontal)
        .frame(height: 40)
    }
    
    var circle: some View {
        Circle()
            .stroke(.primary)
            .frame(width: 40, height: 40)
            .padding()
    }
    
    var body: some View {
        ZStack(alignment: .center) {
            HStack {
                circle
                Spacer()
                circle
            }
            if self.animate {
                dot
                    .transition(.scale)
            }
        }
        .padding()
        .frame(height: 100)
    }
}
