//
//  FloatPickerView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct FloatPickerView: View {
    var title: String
    @Binding var pickervalue: Int
    
    var body: some View {
        HStack {
            Text("\(title):")
                .font(.body)
            Spacer()
            Menu {
                Picker("\(title): ", selection: $pickervalue) {
                    ForEach(0..<21) {
                        Text("\($0.pickerFloatFormat)")
                    }
                }
            } label: {
                HStack {
                    Text("\(pickervalue.pickerFloatFormat)")
                        .font(.body)
                        .frame(width: 30)
                    Image(systemName: "chevron.forward")
                        .aspectRatio(contentMode: .fit)
                }
            }
        }
        .padding()
        .background(Color.systemBackground)
        .cornerRadius(10)
    }
}
