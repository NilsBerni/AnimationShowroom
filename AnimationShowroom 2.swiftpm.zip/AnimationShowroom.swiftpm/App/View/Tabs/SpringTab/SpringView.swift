//
//  SpringView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct SpringView: View {
    @StateObject var vm = SpringViewModel()
    @Environment(\.colorScheme) var colorScheme
    
    var selectAnimation: some View {
        ZStack {
            CardView()
            SpringConfigureView(response: $vm.response, dampingFraction: $vm.dampingFraction, blendDuration: $vm.blendDuration)
        }
        .padding(.bottom, 30)
    }
    
    var body: some View {
        VStack {
            DotAnimationView(move: $vm.move, animate: $vm.animate, animation: vm.adjustedAnimation)
            Spacer()
            selectAnimation
        }
        .navigationTitle("Spring")
        .onChange(of: vm.response, perform: { _ in
            vm.resetAnimation()
        })
        .onChange(of: vm.dampingFraction, perform: { _ in
            vm.resetAnimation()
        })
        .onChange(of: vm.blendDuration, perform: { _ in
            vm.resetAnimation()
        })
        .onAppear(perform: self.vm.initiateAnimation)
    }
}



struct SpringView_Previews: PreviewProvider {
    static var previews: some View {
        SpringView()
    }
}

