//
//  SpringConfigureView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct SpringConfigureView: View {
    @Binding var response: Int
    @Binding var dampingFraction: Int
    @Binding var blendDuration: Int
    
    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            VStack(alignment: .leading) {
                Text(AttributedString(text: "Animation.spring(", highlight: "spring"))
                Text(AttributedString(text: "    response: \(response.pickerFloatFormat),", highlight: "response"))
                Text(AttributedString(text: "    dampingFraction: \(dampingFraction.pickerFloatFormat),", highlight: "dampingFraction"))
                Text(AttributedString(text: "    blendDuration: \(blendDuration.pickerFloatFormat)", highlight: "blendDuration"))
                Text(")")
            }
            .font(Font.title2.bold())
            .lineLimit(1)
            Spacer()
            FloatPickerView(title: "response", pickervalue: $response)
            FloatPickerView(title: "dampingFraction", pickervalue: $dampingFraction)
            FloatPickerView(title: "blendDuration", pickervalue: $blendDuration)
        }.padding(40)
    }
}
