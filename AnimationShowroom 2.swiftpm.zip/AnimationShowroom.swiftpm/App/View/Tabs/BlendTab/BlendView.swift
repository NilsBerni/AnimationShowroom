//
//  SwiftUIView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct BlendView: View {
    var body: some View {
        VStack {
            RectangleView(type: .blend)
        }
        .navigationTitle("Blend")
    }
}

struct BlendView_Previews: PreviewProvider {
    static var previews: some View {
        BlendView()
    }
}
