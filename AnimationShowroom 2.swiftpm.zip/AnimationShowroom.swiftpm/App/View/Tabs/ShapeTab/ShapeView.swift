//
//  ShapeView.swift
//
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct ShapeView: View {
    var body: some View {
        VStack {
            RectangleView(type: .shape)
        }
        .navigationTitle("Shape")
    }
}

struct ShapeView_Previews: PreviewProvider {
    static var previews: some View {
        ShapeView()
    }
}
