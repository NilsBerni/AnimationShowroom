//
//  SwiftUIView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct TransformView: View {
    var body: some View {
        VStack {
            RectangleView(type: .transform)
        }
        .navigationTitle("Transform")
    }
}

struct TransformView_Previews: PreviewProvider {
    static var previews: some View {
        TransformView()
    }
}
