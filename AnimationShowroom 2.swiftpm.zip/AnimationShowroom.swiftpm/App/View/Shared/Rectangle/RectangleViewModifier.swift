//
//  RectangleViewModifier.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct RectangleViewModifier: ViewModifier {
    var move: Bool
    var type: FormType
    
    func body(content: Content) -> some View {
        
        switch (type) {
        case .opacity:
            content.opacity(move ? 0 : 1.0)
        case .color:
            content.overlay(move ? Color.accentColor : Color.primary)
        case .shadow:
            content.shadow(color: .primary, radius: move ? 100 : 0, x: 0, y: 0)
        case .cornerRadius:
            content.cornerRadius(move ? 80 : 0)
        case .width:
            content.scaleEffect(move ? CGSize(width: 1, height: 1) : CGSize(width: 0.2, height: 1))
        case .height:
            content.scaleEffect(move ? CGSize(width: 1, height: 1) : CGSize(width: 1, height: 0.2))
        case .xFlip:
            content.rotation3DEffect(.degrees(move ? 180 : 0), axis: (x: 1, y: 0, z: 0))
        case .yFlip:
            content.rotation3DEffect(.degrees(move ? 180 : 0), axis: (x: 0, y: 1, z: 0))
        case .zFlip:
            content.rotation3DEffect(.degrees(move ? 180 : 0), axis: (x: 0, y: 0, z: 1))
        case .rotate:
            content.rotationEffect(.degrees(move ? 180 : 0))
        }
        
    }
}
