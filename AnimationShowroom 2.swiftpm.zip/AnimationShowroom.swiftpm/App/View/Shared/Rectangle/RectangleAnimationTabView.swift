//
//  RectangleAnimationTabView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct RectangleAnimationTabView: View {
    var selected: FormType
    
    var body: some View {
        ZStack {
            CardView()
            VStack(spacing: 40) {
                Text(selected.code)
                    .font(.title2).bold()
                
            }.padding(40)
        }
        .padding(.bottom, 30)
    }
}

struct RectangleAnimationTabView_Previews: PreviewProvider {
    static var previews: some View {
        AnimationRow(title: "Timing", description: "Learn about animation timing curves.", systemName: "arrow.up.and.down.and.arrow.left.and.right")
    }
}
