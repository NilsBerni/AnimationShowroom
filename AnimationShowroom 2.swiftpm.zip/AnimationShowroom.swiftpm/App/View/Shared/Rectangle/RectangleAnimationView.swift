//
//  RectangleAnimationView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct RectangleAnimationView: View {
    @Binding var move: Bool
    @Binding var animate: Bool
    var type: FormType
    
    var body: some View {
        Rectangle()
        .fill(.primary)
        .frame(width: 180, height: 180)
        .form(move: move, type: type)
        .animation(
            self.animate ? .easeInOut(duration: 1).repeatForever(autoreverses: true) : nil,
            value: self.move
        )
        .padding(80)
    }
}
