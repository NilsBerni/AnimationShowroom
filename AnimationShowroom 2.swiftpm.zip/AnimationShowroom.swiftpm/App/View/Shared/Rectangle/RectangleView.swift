//
//  FormView.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

struct RectangleView: View {
    @StateObject var vm = FormViewModel()
    @Environment(\.colorScheme) var colorScheme
    var type: FormCategoryType
    
    var selectFormModifier: some View {
        TabView(selection: $vm.selectedItem) {
            ForEach(vm.models(type: type).indices, id: \.self) { index in
                RectangleAnimationTabView(selected: vm.models(type: type)[index])
                    .tag(index)
            }
        }
        .tabViewStyle(.page)
        .indexViewStyle(.page(backgroundDisplayMode: colorScheme == .dark ? .never : .always))
    }
    
    var body: some View {
        VStack {
            RectangleAnimationView(move: $vm.move, animate: $vm.animate, type: vm.selectedForm(type: type))
                .scaleEffect(vm.animate ? 1 : 0)
            Spacer()
            selectFormModifier
        }
        .onChange(of: vm.selectedItem, perform: { _ in
            vm.resetAnimation()
        })
        .onAppear(perform: self.vm.initiateAnimation)
    }
}

struct RectangleView_Previews: PreviewProvider {
    static var previews: some View {
        RectangleView(type: .blend)
    }
}
