//
//  Int.swift
//  
//
//  Created by Nils Bernschneider on 05.04.22.
//

import SwiftUI

extension Int {
    
    var pickerFloat: Double {
        let double = Double(self) * 0.1
        return double
    }
    var pickerFloatFormat: String {
        let double = self.pickerFloat
        let formatted = String(format: "%.1f", double)
        return formatted
    }
}
