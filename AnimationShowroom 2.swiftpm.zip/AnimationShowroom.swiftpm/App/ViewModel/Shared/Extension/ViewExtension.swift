//
//  View.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

extension View {
    func form(move: Bool, type: FormType) -> some View {
        modifier(RectangleViewModifier(move: move, type: type))
    }
}
