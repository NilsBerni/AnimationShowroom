//
//  AttributedString.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

extension AttributedString {
    init(text: String, highlight: String) {
        self.init(text: text, highlight: [highlight])
    }
    
    init(text: String, highlight: [String]) {
        var attrString: AttributedString = AttributedString(text)
        for highlighted in highlight {
            if let range = attrString.range(of: highlighted) {
                attrString[range].foregroundColor = .accentColor
            }
        }
        self = attrString
    }
}
