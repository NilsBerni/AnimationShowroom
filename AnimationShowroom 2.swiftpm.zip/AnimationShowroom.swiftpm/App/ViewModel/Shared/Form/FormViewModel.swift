//
//  FormViewModel.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

class FormViewModel: AnimationViewModel {
    @Published var selectedItem = 0
    
    func selectedForm(type: FormCategoryType) -> FormType {
        let models = models(type: type)
        return models[selectedItem]
    }
    
    func models(type: FormCategoryType) -> [FormType] {
        switch (type) {
        case .blend:
            return [
                FormType.opacity,
                FormType.color,
                FormType.shadow
            ]
        case .shape:
            return [
                FormType.cornerRadius,
                FormType.width,
                FormType.height
            ]
        case .transform:
            return [
                FormType.xFlip,
                FormType.yFlip,
                FormType.rotate
            ]
        }
    }
}
