//
//  AnimationViewModel.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI
import AVFoundation

class AnimationViewModel: ObservableObject {
    @Published var move = false
    @Published var animate = true
    
    func initiateAnimation() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
            self.move.toggle()
        })
    }
    
    func hideAnimation() {
        self.animate = false
    }
    
    func showAnimation() {
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: {
            if !self.animate {
                withAnimation(.easeOut) {
                    self.animate = true
                }
                self.move.toggle()
            }
        })
    }
    
    func resetAnimation() {
        
        if !animate {
            return
        }

        hideAnimation()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25, execute: {
            self.showAnimation()
        })
    }
}

