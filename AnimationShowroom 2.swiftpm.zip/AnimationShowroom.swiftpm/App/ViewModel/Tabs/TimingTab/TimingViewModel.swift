//
//  TimingViewModel.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

class TimingViewModel: AnimationViewModel {
    @Published var selectedItem = 0
    
    var selectedAnimation: TimingModel {
        return animations[selectedItem]
    }
    
    var animations = [
        TimingModel(type: .linear),
        TimingModel(type: .easeIn),
        TimingModel(type: .easeOut),
        TimingModel(type: .easeInOut),
        TimingModel(type: .spring)
    ]
}
