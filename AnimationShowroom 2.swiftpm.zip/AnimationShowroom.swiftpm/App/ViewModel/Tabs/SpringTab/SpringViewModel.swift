//
//  SpringViewModel.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

class SpringViewModel: AnimationViewModel {
    @Published var response: Int = 10
    @Published var dampingFraction: Int = 10
    @Published var blendDuration: Int = 10
    
    var selectedAnimation: Animation {
        return .spring(response: response.pickerFloat, dampingFraction: dampingFraction.pickerFloat, blendDuration: blendDuration.pickerFloat)
    }
    
    var adjustedAnimation: AnimationHash {
        return AnimationHash(animation: selectedAnimation.repeatForever(autoreverses: true))
    }
}
