//
//  MoveViewModel.swift
//  
//
//  Created by Nils Bernschneider on 06.04.22.
//

import SwiftUI

class MoveViewModel: AnimationViewModel {
    @Published var x: Bool = true
    @Published var y: Bool = true
}
