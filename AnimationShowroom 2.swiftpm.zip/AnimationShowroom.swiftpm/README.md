# Animation Showroom | WWDC22 Submission

Learn about Swift animations in an interactive fun way.  

## Overview

Welcome to Animation Showroom. This Swift Playgrounds app project shows different types of animations in action. Also, see how other code examples work in action. 

Click on the animation categories you are interested in and choose or modify different animations. 

## Technology

I entirely built this project with SwiftUI

## Device/Mods

I designed the app to work on iPhones, iPads (light or dark appearance)

## Running (Built for Xcode 13.3)

- Unzip AnimationShowroom.swiftpm.zip
- Open with Xcode
- Run
